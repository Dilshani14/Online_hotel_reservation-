var rooms = [
  {
    title: "Room Only - 70% Special Offer",
    description: "This rate plan includes 70% discount on Room only basis ",
    price: "USD 234.11 per night",
    image: "assets/package_room/room_1jpg",
  },
  {
    title: "Bed & Breakfast - 50% Special Offer",
    description:
      "This rate plan includes 50% discount on Bed & Breakfast basis .",
    price: "USD 197.60 per night ",
    image: "assets/package_room/room_2jpg",
  },
  {
    title: "Half Board - 25% Special Offer",
    description: "This rate includes 25% discount on Half Board basis rates.",
    price: "USD 230.40 per night ",
    image: "assets/package_room/room_3jpg",
  },
  {
    title: "Full Board - 23% Special Offer",
    description: "This rate plan includes 23% discount on Full Board basis .",
    price: "USD 252.40 per night",
    image: "assets/package_room/room_4jpg",
  },
  {
    title: "Bed & Breakfast",
    description:
      "Indulge your taste for modern luxury combined with safari chic in the peaceful and hospitable environment that is Jetwing Yala. Further to the experience this...",
    price: " USD 282.30 per night",
    image: "assets/package_room/room_5jpg",
  },
  {
    title: "Room Only",
    description:
      "Indulge your taste for modern luxury combined with safari chic in the peaceful and hospitable environment that is Jetwing Yala. Each room has an en-suite...",
    price: " USD 267.30 per night",
    image: "assets/package_room/room_6jpg",
  },
  {
    title: "Half Board",
    description:
      "Indulge your taste for modern luxury combined with safari chic in the peaceful and hospitable environment that is Jetwing Yala. Further to the experience this...",
    price: " USD 307.30 per night",
    image: "assets/package_room/room_1jpg",
  },
  {
    title: "Full Board-",
    description:
      "Indulge your taste for modern luxury combined with safari chic in the peaceful and hospitable environment that is Jetwing Yala. Further to the experience, this...",
    price: "USD 377.30 per night ",
    image: "assets/package_room/room_2jpg",
  },
];

function loadFunction() {
  for (var key in rooms) {
    for (var i = 0; i < rooms[key].length; i++) {
      var title = rooms[key][i].title;
      var description = rooms[key][i].description;
      var price = rooms[key][i].Price;
      var image = rooms[key][i].image;
      var badge = document.createElement("div");
      badge.className = "badge";
      badge.innerHTML =
        '<div class="row ui_card_1">' +
        '<div class="col-md-4 col-sm-8 col-xs-4 c_1">' +
        "<img src=" +
        image +
        'class="img-fluid" alt="Responsive image"/>' +
        "</div>" +
        '<div class="col-md-8 col-sm-8 col-xs-12 c_2">' +
        '<div class="row">' +
        '<div class="col-md-12 c_5">' +
        "<h3>" +
        title +
        "</h3>" +
        "</div>" +
        "</div>" +
        ' <div class="row">' +
        '<div class="col-md-9 col-sm-9 col-xs-12 c_3"> ' +
        "<p>" +
        description +
        '<a href="#">Read more....</a>' +
        " </p>" +
        "</div>" +
        ' <div class="col-md-3 col-sm-3 col-xs-12 c_4">' +
        '<div class="price_">' +
        '<span class="from_price">From</span>' +
        price +
        " </div>" +
        " </div>" +
        "</div>" +
        ' <div class="row">' +
        ' <div class="col-md-12 sm-12 col-xs-12 c_7">' +
        "</div>" +
        " </div>" +
        "</div>" +
        "</div>";
      //'<h1>' + title + '</h1>' +
      //'<h2>' + desc + '</h1>' +
      //'<div class="options-only-phone">' +
      //'<a class="service-provider-call" href="#" target="_blank"> Buy for $' + price + '</a>';
      //I gave the div the same ID's as the keys in the object for ease
      document.getElementById('.card_container').appendChild(badge);
    }
  }
}

function loadFunction() {
  alert("Hello! I am an alert box!");
}